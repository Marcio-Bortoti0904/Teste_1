
import React from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Home from './pages/Home';
import Watch from './pages/Watch';
import Upload from './pages/Upload';

const App: React.FC = () => {
  return (
    <HashRouter>
      <div className="bg-brand-dark min-h-screen">
        <Header />
        <div className="flex">
          <Sidebar />
          <main className="flex-grow p-4 sm:p-6 ml-0 sm:ml-20 lg:ml-64 transition-all duration-300">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/watch/:videoId" element={<Watch />} />
              <Route path="/upload" element={<Upload />} />
            </Routes>
          </main>
        </div>
      </div>
    </HashRouter>
  );
};

export default App;
