
import React from 'react';
import { useParams } from 'react-router-dom';
import { useAppContext } from '../contexts/AppContext';
import CommentSection from '../components/CommentSection';
import VideoCard from '../components/VideoCard';

const ThumbsUpIcon = ({ className }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className || "h-6 w-6"} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 18.236V6.764l3.057-2.293A1 1 0 0111.414 5H14v5zM4 21V9h2v12H4z" />
    </svg>
);
const ThumbsDownIcon = ({ className }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className || "h-6 w-6"} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14H5.236a2 2 0 01-1.789-2.894l3.5-7A2 2 0 018.738 3h4.017c.163 0 .326.02.485.06L17 5.764v11.472l-3.057 2.293A1 1 0 0112.586 19H10v-5zM20 3v12h-2V3h2z" />
    </svg>
);
const ShareIcon = ({ className }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className || "h-6 w-6"} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 12v8a2 2 0 002 2h12a2 2 0 002-2v-8m-4-6l-4-4m0 0l-4 4m4-4v12" />
    </svg>
);

const Watch: React.FC = () => {
  const { videoId } = useParams<{ videoId: string }>();
  const { videos, likeVideo } = useAppContext();
  const video = videos.find((v) => v.id === videoId);
  const suggestedVideos = videos.filter((v) => v.id !== videoId);

  if (!video) {
    return <div className="text-center text-xl mt-10">Video not found.</div>;
  }
  
  const handleLike = () => {
    if (video) {
        likeVideo(video.id);
    }
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6">
      <div className="lg:w-2/3">
        <div className="aspect-video bg-black rounded-xl overflow-hidden">
            <img src={video.thumbnailUrl.replace('480/270', '1280/720')} alt={video.title} className="w-full h-full object-cover" />
        </div>
        <h1 className="text-2xl font-bold mt-4">{video.title}</h1>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mt-4">
          <div className="flex items-center space-x-3">
            <img src={video.channel.avatarUrl} alt={video.channel.name} className="w-12 h-12 rounded-full" />
            <div>
              <p className="font-semibold">{video.channel.name}</p>
              <p className="text-sm text-brand-light-gray">2.3M subscribers</p>
            </div>
            <button className="ml-4 bg-white text-black font-semibold px-4 py-2 rounded-full hover:bg-gray-200">Subscribe</button>
          </div>
          <div className="flex items-center space-x-2 mt-4 sm:mt-0">
            <div className="flex items-center bg-brand-light-dark rounded-full">
              <button onClick={handleLike} className="flex items-center space-x-2 px-4 py-2 hover:bg-brand-dark-gray rounded-l-full">
                <ThumbsUpIcon />
                <span>{video.likes.toLocaleString()}</span>
              </button>
              <div className="w-px h-6 bg-brand-dark-gray"></div>
              <button className="px-4 py-2 hover:bg-brand-dark-gray rounded-r-full">
                <ThumbsDownIcon />
              </button>
            </div>
            <button className="flex items-center space-x-2 px-4 py-2 bg-brand-light-dark rounded-full hover:bg-brand-dark-gray">
              <ShareIcon />
              <span>Share</span>
            </button>
          </div>
        </div>
        <div className="bg-brand-light-dark p-4 rounded-xl mt-4">
          <p className="font-semibold">{video.views.toLocaleString()} views &nbsp; {new Date(video.timestamp).toLocaleDateString()}</p>
          <p className="mt-2 text-sm">{video.description}</p>
        </div>
        <CommentSection videoId={video.id} comments={video.comments} />
      </div>
      <div className="lg:w-1/3">
        <h2 className="text-xl font-bold mb-4">Up next</h2>
        <div className="space-y-4">
          {suggestedVideos.map(sv => <VideoCard key={sv.id} video={sv} />)}
        </div>
      </div>
    </div>
  );
};

export default Watch;
