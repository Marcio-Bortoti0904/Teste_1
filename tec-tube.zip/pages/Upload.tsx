
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../contexts/AppContext';

const Upload: React.FC = () => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [thumbnailUrl, setThumbnailUrl] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  
  const { addVideo } = useAppContext();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !description || !thumbnailUrl) {
      alert('Please fill all fields');
      return;
    }
    
    setIsUploading(true);

    // Simulate upload delay
    setTimeout(() => {
        addVideo({
            title,
            description,
            thumbnailUrl,
            videoUrl: '', // In a real app, this would be the URL of the processed video
        });
        setIsUploading(false);
        navigate('/');
    }, 1500);
  };

  return (
    <div className="max-w-2xl mx-auto p-4 sm:p-8 bg-brand-light-dark rounded-xl">
      <h1 className="text-3xl font-bold mb-6 text-center">Upload Video</h1>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-brand-light-gray mb-2">
            Title
          </label>
          <input
            type="text"
            id="title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full bg-brand-dark border border-brand-dark-gray rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 text-white"
            placeholder="Enter video title"
          />
        </div>
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-brand-light-gray mb-2">
            Description
          </label>
          <textarea
            id="description"
            rows={4}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full bg-brand-dark border border-brand-dark-gray rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 text-white"
            placeholder="Tell viewers about your video"
          ></textarea>
        </div>
        <div>
          <label htmlFor="thumbnailUrl" className="block text-sm font-medium text-brand-light-gray mb-2">
            Thumbnail URL
          </label>
          <input
            type="text"
            id="thumbnailUrl"
            value={thumbnailUrl}
            onChange={(e) => setThumbnailUrl(e.target.value)}
            className="w-full bg-brand-dark border border-brand-dark-gray rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 text-white"
            placeholder="https://picsum.photos/480/270"
          />
        </div>
        <div>
          <label htmlFor="videoFile" className="block text-sm font-medium text-brand-light-gray mb-2">
            Video File (Simulation)
          </label>
           <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-brand-dark-gray border-dashed rounded-md">
                <div className="space-y-1 text-center">
                    <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                        <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    <div className="flex text-sm text-gray-600">
                        <label htmlFor="file-upload" className="relative cursor-pointer bg-brand-dark rounded-md font-medium text-blue-500 hover:text-blue-400 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                            <span>Upload a file</span>
                            <input id="file-upload" name="file-upload" type="file" className="sr-only" />
                        </label>
                        <p className="pl-1 text-brand-light-gray">or drag and drop</p>
                    </div>
                    <p className="text-xs text-brand-light-gray">MP4, MOV, AVI up to 10GB</p>
                </div>
            </div>
        </div>
        <button
          type="submit"
          disabled={isUploading}
          className="w-full bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 focus:ring-offset-brand-light-dark disabled:bg-gray-500 disabled:cursor-wait transition-colors"
        >
          {isUploading ? 'Uploading...' : 'Upload Video'}
        </button>
      </form>
    </div>
  );
};

export default Upload;
