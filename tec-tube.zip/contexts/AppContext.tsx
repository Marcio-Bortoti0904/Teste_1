
import React, { createContext, useState, useContext, ReactNode } from 'react';
import { Video, Comment, User } from '../types';
import { mockVideos, mockUsers } from '../data/mockData';

interface AppContextType {
  videos: Video[];
  addVideo: (video: Omit<Video, 'id' | 'channel' | 'views' | 'likes' | 'timestamp' | 'comments'>) => void;
  likeVideo: (videoId: string) => void;
  addComment: (videoId: string, commentText: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [videos, setVideos] = useState<Video[]>(mockVideos);

  const addVideo = (videoDetails: Omit<Video, 'id' | 'channel' | 'views' | 'likes' | 'timestamp' | 'comments'>) => {
    const newVideo: Video = {
      ...videoDetails,
      id: `vid${videos.length + 1}`,
      channel: mockUsers[0], // Mock current user
      views: 0,
      likes: 0,
      timestamp: new Date(),
      comments: [],
    };
    setVideos(prevVideos => [newVideo, ...prevVideos]);
  };

  const likeVideo = (videoId: string) => {
    setVideos(prevVideos =>
      prevVideos.map(video =>
        video.id === videoId ? { ...video, likes: video.likes + 1 } : video
      )
    );
  };

  const addComment = (videoId: string, commentText: string) => {
    const newComment: Comment = {
      id: `c${Date.now()}`,
      user: mockUsers[1], // Mock current user
      text: commentText,
      timestamp: new Date(),
    };

    setVideos(prevVideos =>
      prevVideos.map(video =>
        video.id === videoId
          ? { ...video, comments: [...video.comments, newComment] }
          : video
      )
    );
  };

  return (
    <AppContext.Provider value={{ videos, addVideo, likeVideo, addComment }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
