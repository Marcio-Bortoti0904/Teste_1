
import React, { useState } from 'react';
import { Comment as CommentType, User } from '../types';
import { useAppContext } from '../contexts/AppContext';

interface CommentProps {
  comment: CommentType;
}

const ThumbsUpIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className || "h-5 w-5"} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 18.236V6.764l3.057-2.293A1 1 0 0111.414 5H14v5zM4 21V9h2v12H4z" />
  </svg>
);
const ThumbsDownIcon = ({ className }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className || "h-5 w-5"} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14H5.236a2 2 0 01-1.789-2.894l3.5-7A2 2 0 018.738 3h4.017c.163 0 .326.02.485.06L17 5.764v11.472l-3.057 2.293A1 1 0 0112.586 19H10v-5zM20 3v12h-2V3h2z" />
    </svg>
);


const Comment: React.FC<CommentProps> = ({ comment }) => {
  return (
    <div className="flex items-start space-x-4">
      <img src={comment.user.avatarUrl} alt={comment.user.name} className="w-10 h-10 rounded-full" />
      <div>
        <div className="flex items-center space-x-2">
          <p className="font-semibold text-sm">{comment.user.name}</p>
          <p className="text-xs text-brand-light-gray">{new Date(comment.timestamp).toLocaleDateString()}</p>
        </div>
        <p className="mt-1 text-white">{comment.text}</p>
        <div className="flex items-center space-x-4 mt-2 text-brand-light-gray">
            <button className="flex items-center space-x-1 hover:text-white"><ThumbsUpIcon /><span className="text-xs"></span></button>
            <button className="hover:text-white"><ThumbsDownIcon /></button>
            <button className="text-xs font-semibold hover:text-white">REPLY</button>
        </div>
      </div>
    </div>
  );
};

interface CommentSectionProps {
  videoId: string;
  comments: CommentType[];
}

const CommentSection: React.FC<CommentSectionProps> = ({ videoId, comments }) => {
  const [commentText, setCommentText] = useState('');
  const { addComment } = useAppContext();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (commentText.trim()) {
      addComment(videoId, commentText);
      setCommentText('');
    }
  };

  return (
    <div className="mt-6">
      <h2 className="text-xl font-bold mb-4">{comments.length} Comments</h2>
      <div className="flex items-start space-x-4 mb-6">
        <img src="https://picsum.photos/seed/user-avatar/48/48" alt="current user" className="w-10 h-10 rounded-full"/>
        <form onSubmit={handleSubmit} className="flex-1">
          <input
            type="text"
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
            placeholder="Add a comment..."
            className="w-full bg-transparent border-b border-brand-dark-gray focus:border-white outline-none pb-1 text-white"
          />
          <div className="flex justify-end space-x-4 mt-2">
            <button type="button" onClick={() => setCommentText('')} className="text-sm font-semibold px-4 py-2 rounded-full hover:bg-brand-light-dark">Cancel</button>
            <button type="submit" disabled={!commentText.trim()} className="text-sm font-semibold px-4 py-2 rounded-full bg-blue-500 hover:bg-blue-600 disabled:bg-brand-dark-gray disabled:cursor-not-allowed">Comment</button>
          </div>
        </form>
      </div>

      <div className="space-y-6">
        {comments.map((comment) => (
          <Comment key={comment.id} comment={comment} />
        ))}
      </div>
    </div>
  );
};

export default CommentSection;
