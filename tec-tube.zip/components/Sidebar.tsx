
import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const HomeIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
    </svg>
);
const ShortsIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
    </svg>
);
const SubscriptionsIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v12a2 2 0 01-2 2z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15l-4-3v6l4-3z" />
    </svg>
);

interface NavItemProps {
  to: string;
  icon: React.ReactNode;
  label: string;
}

const NavItem: React.FC<NavItemProps> = ({ to, icon, label }) => {
    const location = useLocation();
    const isActive = location.pathname === to;
    return (
        <Link to={to} className={`flex flex-col lg:flex-row items-center justify-center lg:justify-start lg:space-x-4 py-3 px-2 lg:px-4 rounded-lg hover:bg-brand-light-dark ${isActive ? 'bg-brand-light-dark' : ''}`}>
            {icon}
            <span className="mt-1 lg:mt-0 text-xs lg:text-sm">{label}</span>
        </Link>
    );
};

const Sidebar: React.FC = () => {
  return (
    <aside className="hidden sm:block fixed top-16 left-0 h-full bg-brand-dark w-20 lg:w-64 border-r border-brand-dark-gray p-2 transition-all duration-300">
      <nav className="flex flex-col space-y-2">
        <NavItem to="/" icon={<HomeIcon />} label="Home" />
        <NavItem to="#" icon={<ShortsIcon />} label="Shorts" />
        <NavItem to="#" icon={<SubscriptionsIcon />} label="Subscriptions" />
      </nav>
    </aside>
  );
};

export default Sidebar;
