
import React from 'react';
import { Link } from 'react-router-dom';

const MenuIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
    </svg>
);

const LogoIcon = () => (
    <svg className="h-7 w-auto text-brand-red" viewBox="0 0 120 28" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
        <path d="M117.4 3.8h-4.9v20.4h4.9v-20.4zM109.9 3.8h-4.9v20.4h4.9v-20.4zM100 13.1c0-4.6-1.6-6.8-5.3-6.8-3.7 0-5.3 2.2-5.3 6.8s1.6 6.8 5.3 6.8c3.7 0 5.3-2.2 5.3-6.8zm-8.3 0c0-3.3 1-5.4 3-5.4s3 2.1 3 5.4-1 5.4-3 5.4-3-2.1-3-5.4zM86.7 4.1v19.8h-2.3l-2.6-8.2h-0.1v8.2h-4.9v-19.8h7.2c3.4 0 4.8 1.4 4.8 4.4 0 2-1 3.4-2.7 4l3 11.4h-2.5l-2.7-10.9h-1.9v6.5zM84.1 8c0-1.4-0.6-2.1-1.9-2.1h-2.5v4.3h2.5c1.3 0 1.9-0.7 1.9-2.2zM71.2 3.8l-4.2 12.6v7.8h-4.9v-7.8l-4.2-12.6h5.2l2.2 7.5c0.4 1.4 0.7 3.2 0.7 3.2h0.1s0.3-1.8 0.7-3.2l2.2-7.5h5.2zM52.2 3.8h-4.9v20.4h4.9v-20.4zM44.7 3.8h-4.9v20.4h4.9v-20.4zM35.1 11.2v-7.1h-4.9v19.8h4.9v-9.4c0-2.6 0.3-4 2.1-4h0.1l2.1 13.4h5l-2.3-14.5c-0.6-3.8-2.2-5.3-5-5.3h-2zM15.4 17.5l-2.4-9.3-2.4 9.3h-4.9l4.6-16.1h5.1l4.6 16.1h-4.7z"/>
        <path d="M29.15,2.8C25.32,2.8,22.2,5.92,22.2,9.75v8.5c0,3.83,3.12,6.95,6.95,6.95s6.95-3.12,6.95-6.95v-8.5 C36.1,5.92,32.98,2.8,29.15,2.8z M29.15,22.2c-2.18,0-3.95-1.77-3.95-3.95v-8.5c0-2.18,1.77-3.95,3.95-3.95s3.95,1.77,3.95,3.95 v8.5C33.1,20.43,31.33,22.2,29.15,22.2z M11.5,14c0,2.48-2.02,4.5-4.5,4.5S2.5,16.48,2.5,14s2.02-4.5,4.5-4.5h0.01 C9.48,9.5,11.5,11.52,11.5,14z M7,14c0-0.83-0.67-1.5-1.5-1.5S4,13.17,4,14s0.67,1.5,1.5,1.5S7,14.83,7,14z" fill="#FF0000"/>
    </svg>
);


const SearchIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
    </svg>
);
const UploadIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
  </svg>
);


const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-50 flex items-center justify-between px-4 py-2 bg-brand-dark border-b border-brand-dark-gray">
      <div className="flex items-center">
        <button className="p-2 rounded-full hover:bg-brand-light-dark mr-4 hidden sm:block">
            <MenuIcon />
        </button>
        <Link to="/" className="flex items-center gap-2">
            <LogoIcon />
        </Link>
      </div>

      <div className="flex-1 flex justify-center px-4 lg:px-16">
        <div className="w-full max-w-2xl flex items-center">
          <input
            type="text"
            placeholder="Search"
            className="w-full bg-brand-dark border border-brand-dark-gray rounded-l-full px-4 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500 text-white"
          />
          <button className="bg-brand-light-dark px-6 py-2 rounded-r-full border border-l-0 border-brand-dark-gray hover:bg-brand-dark-gray">
            <SearchIcon />
          </button>
        </div>
      </div>

      <div className="flex items-center space-x-4">
        <Link to="/upload" className="p-2 rounded-full hover:bg-brand-light-dark">
          <UploadIcon />
        </Link>
        <img
          src="https://picsum.photos/seed/user-avatar/40/40"
          alt="User Avatar"
          className="w-8 h-8 rounded-full cursor-pointer"
        />
      </div>
    </header>
  );
};

export default Header;
